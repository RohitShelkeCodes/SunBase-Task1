package com.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.CustomerDao;
import com.model.Customer;

public class FristServlet extends HttpServlet {
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		if(req.getParameter("b1").equalsIgnoreCase("add"))
		{
			Customer c = new Customer();
			c.setFirst_name(req.getParameter("frist_name"));
			c.setLast_name(req.getParameter("last_name"));
			c.setAddress(req.getParameter("address"));
			c.setState(req.getParameter("state"));
			c.setCity(req.getParameter("city"));
			c.setEmail(req.getParameter("email"));
			c.setPhone(req.getParameter("phone"));
			new CustomerDao().insertCustomer(c);
			res.sendRedirect("Frist.jsp");
			}
		if(req.getParameter("b1").equalsIgnoreCase("Delete"))
		{
			new CustomerDao().deleteByCid(Integer.parseInt(req.getParameter("cid")));
			res.sendRedirect("index.jsp");
		}
		if(req.getParameter("b1").equalsIgnoreCase("Display"))
		{
			Customer c = new CustomerDao().findCustomerByCid(Integer.parseInt(req.getParameter("cid")));
			if (c == null)
				res.sendRedirect("index.jsp");
			else {
				req.setAttribute("Customer", c);
				req.getRequestDispatcher("Second.jsp").forward(req, res);
			}
		}
		if(req.getParameter("b1").equalsIgnoreCase("Update"))
		{
			Customer c = new Customer();
			c.setFirst_name(req.getParameter("frist_name"));
			c.setLast_name(req.getParameter("last_name"));
			c.setAddress(req.getParameter("address"));
			c.setState(req.getParameter("state"));
			c.setCity(req.getParameter("city"));
			c.setEmail(req.getParameter("email"));
			c.setPhone(req.getParameter("phone"));
			
			new CustomerDao().updateCustomer(c);
			res.sendRedirect("index.jsp");
		}
	}

}
