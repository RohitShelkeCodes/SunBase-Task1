package com.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Order;

import com.model.Customer;
import com.util.HBUtils;

public class CustomerDao {
	
	private Session session= HBUtils.sf.openSession();
	private Transaction tx= session.beginTransaction();
	
	public int insertCustomer(Customer c) {
		int result =(int) session.save(c);
		closeConnection();
		return result;
	}
	private void closeConnection() {
		tx.commit();
		session.close();
	}
	public List<Customer> findAllCustomer(){
		return session.createCriteria(Customer.class).list();
	}
	public int deleteByCid(int cid)
	{
		int result=session.createQuery("delete from Customer where cid=:a").setParameter("a", cid).executeUpdate();
		closeConnection();
		return result;
	}
	public Customer findCustomerByCid(int cid)
	{
		return session.get(Customer.class, cid);
	}
	
	public void updateCustomer(Customer c)
	{
		session.saveOrUpdate(c);
		tx.commit();
	}
}
